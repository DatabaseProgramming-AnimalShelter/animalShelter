package controller.adopt;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.AdoptApply;
import model.service.AdoptApplyManager;

public class ManagerResultController implements Controller {
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		int apply_id = Integer.parseInt(request.getParameter("apply_id"));
		int apply_result = 0;

		if (request.getMethod().equals("POST")) {
			apply_result = 1; 
		}
		
		AdoptApplyManager manager = AdoptApplyManager.getInstance();
		AdoptApply adoptApply = manager.findAdoptApply(apply_id);
		manager.apply_result(adoptApply, apply_result);

		if(apply_result == 1) {
			List<AdoptApply> adoptApplyList = manager.findAnimalAdoptList(adoptApply.getAnimal_id()); // �씠 �룞臾쇱뿉 ���븳 紐⑤뱺 �엯�뼇 �떊泥� 由ъ뒪�듃 諛섑솚
			Iterator<AdoptApply> iter = adoptApplyList.iterator();
			AdoptApply apply = null;
			apply_result = 0;
			
			while (iter.hasNext()) {
				apply = iter.next();
				manager.apply_result(apply, apply_result);
			}
		}
		List<AdoptApply> list = manager.findAdoptApplyResultList();

		request.setAttribute("AdoptApplyList", list);
		return "/adopt/applyResultList.jsp";
	}
}
