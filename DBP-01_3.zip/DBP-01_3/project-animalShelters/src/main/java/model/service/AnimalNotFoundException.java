package model.service;

public class AnimalNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnimalNotFoundException() {
		super();
	}

	public AnimalNotFoundException(String arg0) {
		super(arg0);
	}
}
