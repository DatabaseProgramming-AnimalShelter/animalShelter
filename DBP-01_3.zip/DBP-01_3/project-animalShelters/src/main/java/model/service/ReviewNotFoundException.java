package model.service;

public class ReviewNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public ReviewNotFoundException() {
		super();
	}

	public ReviewNotFoundException(String arg0) {
		super(arg0);
	}
}
